﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using ClickableTransparentOverlay;
using ClickableTransparentOverlay.Win32;
using ImGuiNET;
using Vortice.Direct3D;

namespace ImGuiStartMenu
{
    public class Renderer : Overlay
    {

        static void Main(string[] args)
        {
            
        }

        //defaul value
        float sliderValue = 60;
        float sliderValue2 = 10;
        float sliderValue3 = 150;
        int sliderintValue = 1; 

        //default setting
        bool checkboxValue = false;
        bool checkboxValue2 = false;
        bool checkboxValue3 = false;
        bool checkboxValue4 = false;
        bool checkboxValue5 = false;
        bool checkboxValue6 = false;
        bool checkboxValue7 = false;
        bool checkboxValue8 = false;
        bool checkboxValue9 = false;
        bool checkboxValue10 = false;
        bool checkboxValue11 = false;
        protected override void Render()
        {
            ImGui.Begin("scarydevx");
            ImGui.Text("The best cheat for CSS (not work)");
            ImGui.SliderFloat("Fov", ref sliderValue, 58, 140);
            ImGui.SliderFloat("FAC set", ref sliderValue2, 10, 50);
            ImGui.SliderFloat("Esp Size", ref sliderValue3, 150, 2000);
            ImGui.SliderInt("Chams look", ref sliderintValue, 1, 2);
            ImGui.Checkbox("Aimbot", ref checkboxValue);
            ImGui.Checkbox("Auto Shoot", ref checkboxValue11);
            ImGui.Checkbox("Auto Swap", ref checkboxValue4);
            ImGui.Checkbox("Auto Buy", ref checkboxValue6);
            ImGui.Checkbox("Auto Text", ref checkboxValue7);
            ImGui.Checkbox("Anti Bot", ref checkboxValue8);
            ImGui.Checkbox("Bhop", ref checkboxValue5);
            ImGui.Checkbox("Chams", ref checkboxValue3);
            ImGui.Checkbox("Esp", ref checkboxValue2);
            ImGui.Checkbox("Fov Aim Circle", ref checkboxValue9);
            ImGui.Checkbox("Vac Protection", ref checkboxValue10);
        }
    }
}
