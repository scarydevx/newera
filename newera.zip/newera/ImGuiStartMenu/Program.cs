﻿using ImGuiStartMenu;
using Swed64;
using Vortice.DXGI;


//start imgui in a separate thread
Renderer renderer = new Renderer();
Thread renderThread = new Thread(renderer.Start().Wait);
renderThread.Start();