﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClickableTransparentOverlay;
using ImGuiNET;

namespace MIDNIGHT
{
    public class Renderer : Overlay
    {
        public bool godMode = false;
        public bool unlimitedAmmo = false;

        protected override void Render()
        {
            throw new NotImplementedException();
        }
    }
}
